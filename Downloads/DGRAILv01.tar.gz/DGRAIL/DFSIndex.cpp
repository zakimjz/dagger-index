/*
 * DFSIndex.cpp
 *
 *  Created on: Mar 25, 2011
 *      Author: yildih2
 */

#include "DFSIndex.h"

DFSIndex::DFSIndex(Graph& graph): size(graph.size()),
		og(&graph), visited(graph.size()) {
}

DFSIndex::~DFSIndex() {
	// TODO Auto-generated destructor stub
}

int DFSIndex::query(int src, int trg){
	_opCnt++;
	return pquery(src,trg);
}


int DFSIndex::pquery(int src, int trg){
	visited[src] = _opCnt;
	if(src == trg)
		return 1;
	EdgeList &el = (*og)[src].outEdges();
	EdgeList::iterator it;
	for(it=el.begin();it!=el.end();it++){
		if(visited[it->first]!=_opCnt){
			if(pquery(it->first,trg))
				return 1;
		}
	}
	return 0;
}

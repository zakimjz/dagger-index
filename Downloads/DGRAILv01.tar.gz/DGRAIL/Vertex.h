/*
 * Vertex.h
 *
 *  Created on: Mar 11, 2011
 *      Author: yildih2
 */

#ifndef VERTEX_H_
#define VERTEX_H_
#include <unordered_map>
#include <iostream>
using namespace std;
typedef unordered_map<int,int> EdgeList;

class Vertex {
private:
	int id;


public:
	EdgeList inList;
	EdgeList outList;
	EdgeList& outEdges();
	EdgeList& inEdges();
	int outDegree();
	int inDegree();
	int degree();
	int hasEdge(int end);
	void addOutEdge(int tid);
	void addInEdge(int sid);
	void eraseOutEdge(int x);

	Vertex(int);
	Vertex();
	virtual ~Vertex();
};

#endif /* VERTEX_H_ */

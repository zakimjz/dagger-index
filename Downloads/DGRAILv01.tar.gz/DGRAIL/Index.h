/*
 * Index.h
 *
 *  Created on: Mar 25, 2011
 *      Author: yildih2
 */

#ifndef INDEX_H_
#define INDEX_H_

class Index {
protected:

public:
	virtual int query(int, int) = 0;
	virtual void writeIndex(){};
	virtual void integrityCheck(){};
	virtual void printStatistics(){};
	virtual void debug(int){};
};

#endif /* INDEX_H_ */

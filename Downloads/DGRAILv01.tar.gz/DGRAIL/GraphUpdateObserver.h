#ifndef GRAPH_UPDATE_OBSERVER_H_
#define GRAPH_UPDATE_OBSERVER_H_

// ---------------- Observer interface -----------------
class GraphUpdateObserver {
    public:
        virtual void edgeAdded(int,int) = 0;
        virtual void edgeDeleted(int,int) = 0;
        virtual void nodeAdded(int, vector<int>& , vector<int>&) = 0;
        virtual void nodeDeleted(int) = 0;
};

#endif /* GRAPH_UPDATE_OBSERVER_H_  */

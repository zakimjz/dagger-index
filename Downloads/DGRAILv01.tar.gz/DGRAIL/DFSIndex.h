/*
 * DFSIndex.h
 *
 *  Created on: Mar 25, 2011
 *      Author: yildih2
 */

#ifndef DFSIndex_H_
#define DFSIndex_H_
#include <unordered_map>
#include "Index.h"
#include "Graph.h"

using namespace::std;

class DFSIndex : public Index {
protected:
	int size;
	Graph* og;
	unordered_map<int,int> visited;
	int operationCounter;
	int _opCnt;

public:
	DFSIndex();
	DFSIndex(Graph&);
	int query(int, int);
	virtual ~DFSIndex();
private :
	int pquery(int, int);

};

#endif /* DFSIndex_H_ */
